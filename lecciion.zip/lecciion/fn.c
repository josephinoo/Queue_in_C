#include <stdio.h>
int valor =20;
void fn(){

    valor=17;
    printf("cha\n");
}