#include <stdio.h>
void fn();
int valor =9;
int main(){

    valor=4;
    fn();
    printf("%d\n",valor);
}